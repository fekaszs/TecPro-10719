/**
 * 
 */
/**
 * 
 */
module p1 {
	requires java.desktop;
}