package Caso2;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class v2 extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JTextField txtnum;
	private JButton btnNewButton;
	private JButton btnKilometrosAMillas;
	private JButton btnMiinutosASegundos;
	private JScrollPane scrollPane;
	private JTextArea txts;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					v2 frame = new v2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public v2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 451, 416);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel = new JLabel("Digite un numero");
		lblNewLabel.setBounds(10, 11, 98, 21);
		contentPane.add(lblNewLabel);
		
		txtnum = new JTextField();
		txtnum.setBounds(118, 11, 86, 20);
		contentPane.add(txtnum);
		txtnum.setColumns(10);
		
		btnNewButton = new JButton("Celcius a Fahrenhait");
		btnNewButton.addActionListener(this);
		btnNewButton.setBounds(10, 54, 212, 38);
		contentPane.add(btnNewButton);
		
		btnKilometrosAMillas = new JButton("Kilometros a Millas");
		btnKilometrosAMillas.addActionListener(this);
		btnKilometrosAMillas.setBounds(10, 103, 212, 38);
		contentPane.add(btnKilometrosAMillas);
		
		btnMiinutosASegundos = new JButton("Segundos a minutos y segundos");
		btnMiinutosASegundos.addActionListener(this);
		btnMiinutosASegundos.setBounds(10, 152, 212, 38);
		contentPane.add(btnMiinutosASegundos);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 201, 415, 165);
		contentPane.add(scrollPane);
		
		txts = new JTextArea();
		scrollPane.setViewportView(txts);

	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnMiinutosASegundos) {
			do_btnMiinutosASegundos_actionPerformed(e);
		}
		if (e.getSource() == btnKilometrosAMillas) {
			do_btnKilometrosAMillas_actionPerformed(e);
		}
		if (e.getSource() == btnNewButton) {
			do_btnNewButton_actionPerformed(e);
		}
	}
	protected void do_btnNewButton_actionPerformed(ActionEvent e) {
		double num = Double.parseDouble(txtnum.getText());
		Conversor C = new Conversor(num);
		txts.append("De Celcius a Fahrenhar es: "+ C.Convertir(num)+"\n");
	}
	protected void do_btnKilometrosAMillas_actionPerformed(ActionEvent e) {
		int num = Integer.parseInt(txtnum.getText());
		Conversor C = new Conversor(num);
		txts.append("De Kilometros a Millas es: "+ C.Convertir(num)+"\n");
	}
	protected void do_btnMiinutosASegundos_actionPerformed(ActionEvent e) {
		int num = Integer.parseInt(txtnum.getText());
		Conversor C = new Conversor(num, true);
		txts.append(C.Convertir(num, true)+"\n");
	}
}
