package Caso3;

public class Contador {
	private String nom;
	private double sld;
	private static int cant = 0;
	private static double sumasld = .0;
	public Contador(String nom, double sld) {
		this.nom = nom;
		this.sld = sld;
		cant++;			//cada vez que se llame al constructor se contara;
		sumasld+=sld;	//cada vez que se llame al constructor se contara;
	}
	public int Contador() {
		return cant;
	}
	public double Suma_Sueldo() {
		return sumasld;
	}
	
}
