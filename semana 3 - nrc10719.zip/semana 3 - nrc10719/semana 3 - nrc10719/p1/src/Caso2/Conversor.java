package Caso2;

public class Conversor {
	private double clss;
	private int km, seg;
	
	public Conversor(double clss) {
		this.clss = clss;
	}

	public Conversor(int km) {
		this.km = km;
	}

	public Conversor(int seg, boolean flag) {
		this.seg = seg;
	}
	
	 public double Convertir(double clss) {
		 return 9/5*clss+32;
	 }
	 
	 public double Convertir(int km) {
		 return km*0.62137;
	 }
	 
	 public String Convertir(int seg, boolean flag) {
		 int segundos = seg%60;
		 int min = seg/60;
		 return min+" minutos y " + segundos + " segundos";
	 }
	 
}
